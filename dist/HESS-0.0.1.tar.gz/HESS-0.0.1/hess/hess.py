import libhess


def sequence(n, oracle):
    return libhess.sequence(n, oracle)


def binary(n, oracle):
    return libhess.binary(n, oracle)
